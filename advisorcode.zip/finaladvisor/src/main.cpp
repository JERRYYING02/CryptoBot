#include <iostream>
#include <string>
#include <vector>
#include "OrderBookEntry.h"
#include "AdvisorBot.h"
#include "CSVReader.h"

//call init function in main
int main()
{
    AdvisorBot app{};
    app.init();
}





 
